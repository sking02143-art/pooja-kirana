'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { CATEGORIES } from '@/lib/config';
import { fetchProducts } from '@/lib/products';
import ProductCard from './ProductCard';

function Skeleton() {
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 lg:gap-5">
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i} className="overflow-hidden rounded-2xl border border-gray-100 bg-white">
          <div className="aspect-square animate-pulse bg-brand-50" />
          <div className="space-y-2 p-3">
            <div className="h-3 w-1/3 animate-pulse rounded bg-gray-100" />
            <div className="h-4 w-4/5 animate-pulse rounded bg-gray-100" />
            <div className="h-9 animate-pulse rounded-xl bg-gray-100" />
          </div>
        </div>
      ))}
    </div>
  );
}

export default function Shop() {
  const [products, setProducts] = useState([]);
  const [status, setStatus] = useState('loading'); // loading | ready | error
  const [source, setSource] = useState('');
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('All');

  const load = useCallback(async () => {
    setStatus('loading');
    try {
      const res = await fetchProducts();
      setProducts(res.products);
      setSource(res.source);
      setStatus('ready');
    } catch {
      setStatus('error');
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return products.filter((p) => {
      if (category !== 'All' && p.category !== category) return false;
      if (!q) return true;
      return (
        p.name.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        (p.description || '').toLowerCase().includes(q)
      );
    });
  }, [products, query, category]);

  const tabs = [{ name: 'All', emoji: '🛒' }, ...CATEGORIES];

  return (
    <section id="shop" className="mx-auto max-w-6xl scroll-mt-16 px-4 py-8">
      <div className="relative">
        <svg
          viewBox="0 0 24 24"
          className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <circle cx="11" cy="11" r="7" />
          <path d="m21 21-4.3-4.3" />
        </svg>
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Saaman khojein: atta, dal, tel..."
          aria-label="Product search"
          className="input !rounded-2xl !py-3.5 !pl-12 shadow-card"
        />
      </div>

      <div className="no-scrollbar -mx-4 mt-5 flex gap-3 overflow-x-auto px-4 pb-2">
        {tabs.map((c) => {
          const active = category === c.name;
          return (
            <button
              key={c.name}
              type="button"
              onClick={() => setCategory(c.name)}
              aria-pressed={active}
              className="flex shrink-0 flex-col items-center gap-1.5 transition active:scale-95"
            >
              <span
                className={`flex h-14 w-14 items-center justify-center rounded-2xl text-2xl transition ${
                  active
                    ? 'bg-brand-600 shadow-soft ring-2 ring-brand-300'
                    : 'bg-brand-50 hover:bg-brand-100'
                }`}
              >
                {c.emoji}
              </span>
              <span className={`text-xs font-semibold ${active ? 'text-brand-700' : 'text-gray-600'}`}>
                {c.name}
              </span>
            </button>
          );
        })}
      </div>

      {source === 'sample' && (
        <p className="mt-4 rounded-xl bg-amber-50 px-4 py-2.5 text-xs text-amber-800">
          Demo mode: Supabase abhi connect nahi hai, isliye sample products dikh rahe hain. .env.local mein keys daalein.
        </p>
      )}
      {source === 'cache' && (
        <p className="mt-4 rounded-xl bg-amber-50 px-4 py-2.5 text-xs text-amber-800">
          Internet nahi mil raha, isliye pichli baar ki saved list dikh rahi hai. Daam badle ho sakte hain.
        </p>
      )}

      <div className="mt-5">
        {status === 'loading' && <Skeleton />}

        {status === 'error' && (
          <div className="rounded-2xl border border-red-100 bg-red-50 p-6 text-center">
            <p className="font-semibold text-red-700">Products load nahi ho paaye.</p>
            <p className="mt-1 text-sm text-red-600">Internet check karein aur dobara koshish karein.</p>
            <button type="button" onClick={load} className="btn-primary mt-4">
              Dobara koshish karein
            </button>
          </div>
        )}

        {status === 'ready' && filtered.length === 0 && (
          <div className="rounded-2xl bg-brand-50 p-8 text-center">
            <p className="text-3xl">🔍</p>
            <p className="mt-2 font-semibold text-brand-800">
              {products.length === 0 ? 'Abhi koi product nahi hai.' : 'Koi saaman nahi mila.'}
            </p>
            {products.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  setQuery('');
                  setCategory('All');
                }}
                className="btn-outline mt-4"
              >
                Filter hatayein
              </button>
            )}
          </div>
        )}

        {status === 'ready' && filtered.length > 0 && (
          <>
            <p className="mb-3 text-sm text-gray-500">{filtered.length} products</p>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 lg:gap-5">
              {filtered.map((p, i) => (
                <ProductCard key={p.id} product={p} index={i} />
              ))}
            </div>
          </>
        )}
      </div>
    </section>
  );
}
