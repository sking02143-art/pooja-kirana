'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useCart } from '@/lib/cart';
import { formatPrice } from '@/lib/utils';

export default function CartBar() {
  const { count, total } = useCart();
  const pathname = usePathname();

  if (count === 0 || pathname !== '/') return null;

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-0 z-40 px-4 pb-4">
      <Link
        href="/cart"
        className="pointer-events-auto mx-auto flex max-w-xl animate-fadeUp items-center justify-between rounded-2xl bg-brand-700 px-5 py-3.5 text-white shadow-soft transition active:scale-[0.98]"
      >
        <span className="text-sm font-semibold">
          {count} {count === 1 ? 'item' : 'items'} • {formatPrice(total)}
        </span>
        <span className="flex items-center gap-1 text-sm font-bold">
          Cart dekhein
          <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="m9 18 6-6-6-6" />
          </svg>
        </span>
      </Link>
    </div>
  );
}
