import Link from 'next/link';
import { STORE } from '@/lib/config';
import { whatsappLink } from '@/lib/utils';

export default function Footer() {
  return (
    <footer className="border-t border-brand-100 bg-brand-50/60">
      <div className="mx-auto flex max-w-6xl flex-col gap-3 px-4 py-8 text-sm text-gray-600 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="font-bold text-brand-800">{STORE.name}</p>
          <p>{STORE.tagline}</p>
        </div>
        <div className="flex flex-wrap items-center gap-4">
          <a
            href={whatsappLink(`Namaste ${STORE.name}, mujhe kuch poochna hai.`)}
            target="_blank"
            rel="noopener noreferrer"
            className="font-semibold text-brand-700 hover:underline"
          >
            WhatsApp par baat karein
          </a>
          <Link href="/admin" className="text-gray-400 hover:text-gray-600">
            Admin
          </Link>
        </div>
      </div>
      <p className="border-t border-brand-100 py-3 text-center text-xs text-gray-400">
        © {new Date().getFullYear()} {STORE.name}. Sabhi adhikar surakshit.
      </p>
    </footer>
  );
}
