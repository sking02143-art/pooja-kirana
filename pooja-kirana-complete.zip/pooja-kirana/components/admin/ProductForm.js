'use client';

import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { CATEGORIES } from '@/lib/config';

const EMPTY = {
  name: '',
  category: 'Atta',
  price: '',
  mrp: '',
  unit: '1 kg',
  image_url: '',
  description: '',
  in_stock: true,
};

export default function ProductForm({ product, onClose, onSaved }) {
  const isEdit = Boolean(product && product.id);
  const [form, setForm] = useState(() =>
    isEdit
      ? {
          name: product.name || '',
          category: product.category || 'Atta',
          price: String(product.price ?? ''),
          mrp: product.mrp === null || product.mrp === undefined ? '' : String(product.mrp),
          unit: product.unit || '',
          image_url: product.image_url || '',
          description: product.description || '',
          in_stock: product.in_stock !== false,
        }
      : EMPTY
  );
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setError('');

    const price = Number(form.price);
    const mrp = form.mrp === '' ? null : Number(form.mrp);
    if (form.name.trim().length < 2) return setError('Product ka naam likhein.');
    if (form.price === '' || Number.isNaN(price) || price < 0) return setError('Sahi price likhein.');
    if (mrp !== null && (Number.isNaN(mrp) || mrp < 0)) return setError('MRP sahi likhein ya khali chhodein.');
    if (!form.unit.trim()) return setError('Unit likhein (jaise 1 kg).');

    const payload = {
      name: form.name.trim(),
      category: form.category,
      price,
      mrp,
      unit: form.unit.trim(),
      image_url: form.image_url.trim() || null,
      description: form.description.trim() || null,
      in_stock: form.in_stock,
    };

    setSaving(true);
    const query = isEdit
      ? supabase.from('products').update(payload).eq('id', product.id).select('id')
      : supabase.from('products').insert(payload).select('id');
    const { data, error: err } = await query;
    setSaving(false);

    if (err) return setError(`Save nahi hua: ${err.message}`);
    if (!data || data.length === 0) return setError('Save nahi hua. Shayad aap admin nahi hain.');
    onSaved();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 sm:items-center" role="dialog" aria-modal="true">
      <form
        onSubmit={submit}
        noValidate
        className="max-h-[92vh] w-full max-w-lg animate-fadeUp overflow-y-auto rounded-t-3xl bg-white p-5 shadow-soft sm:rounded-3xl"
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-extrabold text-brand-800">{isEdit ? 'Product edit karein' : 'Naya product jodein'}</h2>
          <button type="button" onClick={onClose} aria-label="Band karein" className="rounded-full p-2 text-gray-500 hover:bg-gray-100">✕</button>
        </div>

        <div className="space-y-3">
          <div>
            <label className="label" htmlFor="p-name">Naam *</label>
            <input id="p-name" className="input" value={form.name} onChange={set('name')} />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label" htmlFor="p-cat">Category *</label>
              <select id="p-cat" className="input" value={form.category} onChange={set('category')}>
                {CATEGORIES.map((c) => (
                  <option key={c.name} value={c.name}>{c.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label" htmlFor="p-unit">Unit *</label>
              <input id="p-unit" className="input" value={form.unit} onChange={set('unit')} placeholder="1 kg / 500 ml" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label" htmlFor="p-price">Bechne ka daam (₹) *</label>
              <input id="p-price" type="number" min="0" step="0.01" inputMode="decimal" className="input" value={form.price} onChange={set('price')} />
            </div>
            <div>
              <label className="label" htmlFor="p-mrp">MRP (₹)</label>
              <input id="p-mrp" type="number" min="0" step="0.01" inputMode="decimal" className="input" value={form.mrp} onChange={set('mrp')} />
            </div>
          </div>

          <div>
            <label className="label" htmlFor="p-img">Image ka link</label>
            <input id="p-img" className="input" value={form.image_url} onChange={set('image_url')} placeholder="https://... ya /products/atta.svg" />
            {form.image_url && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={form.image_url} alt="Preview" className="mt-2 h-20 w-20 rounded-xl bg-brand-50 object-cover" onError={(e) => { e.currentTarget.style.display = 'none'; }} />
            )}
          </div>

          <div>
            <label className="label" htmlFor="p-desc">Description</label>
            <textarea id="p-desc" rows={2} className="input" value={form.description} onChange={set('description')} />
          </div>

          <label className="flex cursor-pointer items-center gap-3 rounded-xl bg-brand-50 p-3 text-sm font-semibold text-brand-800">
            <input
              type="checkbox"
              checked={form.in_stock}
              onChange={(e) => setForm((f) => ({ ...f, in_stock: e.target.checked }))}
              className="h-5 w-5 accent-green-600"
            />
            Stock mein hai
          </label>
        </div>

        {error && <p className="mt-3 rounded-xl bg-red-50 px-3 py-2 text-sm text-red-700">{error}</p>}

        <div className="mt-5 flex gap-3">
          <button type="button" onClick={onClose} className="btn-outline flex-1">Cancel</button>
          <button type="submit" disabled={saving} className="btn-primary flex-1">
            {saving ? 'Save ho raha hai...' : 'Save karein'}
          </button>
        </div>
      </form>
    </div>
  );
}
