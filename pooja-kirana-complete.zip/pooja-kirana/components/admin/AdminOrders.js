'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { ORDER_STATUSES, STATUS_LABELS } from '@/lib/config';
import { formatPrice, whatsappLink } from '@/lib/utils';

const BADGE = {
  new: 'bg-amber-100 text-amber-800',
  confirmed: 'bg-blue-100 text-blue-800',
  delivered: 'bg-brand-100 text-brand-800',
  cancelled: 'bg-gray-200 text-gray-600',
};

export default function AdminOrders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState('all');
  const [open, setOpen] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(200);
    if (error) setError(error.message);
    else setOrders(data || []);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const visible = useMemo(
    () => (filter === 'all' ? orders : orders.filter((o) => o.status === filter)),
    [orders, filter]
  );

  const changeStatus = async (order, status) => {
    setError('');
    const { data, error } = await supabase
      .from('orders')
      .update({ status })
      .eq('id', order.id)
      .select('id');
    if (error || !data?.length) return setError(error?.message || 'Status update nahi hua.');
    setOrders((list) => list.map((o) => (o.id === order.id ? { ...o, status } : o)));
  };

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center gap-2">
        {['all', ...ORDER_STATUSES].map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`rounded-full px-3.5 py-1.5 text-xs font-bold transition ${
              filter === s ? 'bg-brand-600 text-white' : 'bg-brand-50 text-brand-700 hover:bg-brand-100'
            }`}
          >
            {s === 'all' ? 'Sabhi' : STATUS_LABELS[s]}
          </button>
        ))}
        <button onClick={load} className="ml-auto text-xs font-semibold text-brand-700 hover:underline">
          ↻ Refresh
        </button>
      </div>

      {error && <p className="mb-3 rounded-xl bg-red-50 px-4 py-2 text-sm text-red-700">{error}</p>}
      {loading && <p className="py-10 text-center text-gray-500">Load ho raha hai...</p>}
      {!loading && visible.length === 0 && (
        <div className="rounded-2xl bg-brand-50 p-8 text-center text-brand-800">Koi order nahi hai.</div>
      )}

      <ul className="space-y-3">
        {visible.map((o) => {
          const expanded = open === o.id;
          const msg = `Namaste ${o.customer_name}, aapka order ${o.order_number} (${formatPrice(o.total)}) ke baare mein.`;
          return (
            <li key={o.id} className="card overflow-hidden">
              <button
                onClick={() => setOpen(expanded ? null : o.id)}
                className="flex w-full items-center justify-between gap-3 p-4 text-left"
                aria-expanded={expanded}
              >
                <span className="min-w-0">
                  <span className="block truncate text-sm font-bold">
                    {o.order_number} • {o.customer_name}
                  </span>
                  <span className="block text-xs text-gray-500">
                    {new Date(o.created_at).toLocaleString('en-IN')} • {o.payment_method}
                  </span>
                </span>
                <span className="flex shrink-0 flex-col items-end gap-1">
                  <span className="font-extrabold text-brand-800">{formatPrice(o.total)}</span>
                  <span className={`rounded-full px-2.5 py-0.5 text-[11px] font-bold ${BADGE[o.status] || ''}`}>
                    {STATUS_LABELS[o.status] || o.status}
                  </span>
                </span>
              </button>

              {expanded && (
                <div className="space-y-3 border-t border-gray-100 bg-gray-50/60 p-4 text-sm">
                  <div>
                    <p className="font-semibold">Phone: <a className="text-brand-700 underline" href={`tel:${o.phone}`}>{o.phone}</a></p>
                    <p className="mt-1 whitespace-pre-line text-gray-700">Pata: {o.address}</p>
                    {o.notes && <p className="mt-1 text-gray-700">Note: {o.notes}</p>}
                  </div>
                  <ul className="divide-y divide-gray-200 rounded-xl bg-white px-3">
                    {(o.items || []).map((it, i) => (
                      <li key={i} className="flex justify-between gap-3 py-2">
                        <span>{it.name} <span className="text-gray-400">({it.unit}) × {it.qty}</span></span>
                        <span className="font-semibold">{formatPrice(it.price * it.qty)}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="flex flex-wrap items-center gap-3">
                    <label className="flex items-center gap-2 text-xs font-semibold text-gray-600">
                      Status:
                      <select
                        value={o.status}
                        onChange={(e) => changeStatus(o, e.target.value)}
                        className="rounded-lg border border-gray-200 bg-white px-3 py-2 text-sm"
                      >
                        {ORDER_STATUSES.map((s) => (
                          <option key={s} value={s}>{STATUS_LABELS[s]}</option>
                        ))}
                      </select>
                    </label>
                    <a
                      href={whatsappLink(msg, `91${o.phone}`)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn-outline !py-2"
                    >
                      Customer ko WhatsApp
                    </a>
                  </div>
                </div>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
