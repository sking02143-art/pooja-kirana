'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { normalizeProduct } from '@/lib/products';
import { formatPrice } from '@/lib/utils';
import ProductForm from './ProductForm';

export default function AdminProducts() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [editing, setEditing] = useState(null); // null | 'new' | product
  const [query, setQuery] = useState('');
  const [busyId, setBusyId] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) setError(error.message);
    else setProducts((data || []).map(normalizeProduct));
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return products;
    return products.filter((p) => p.name.toLowerCase().includes(q) || p.category.toLowerCase().includes(q));
  }, [products, query]);

  const toggleStock = async (p) => {
    setBusyId(p.id);
    const { data, error } = await supabase
      .from('products')
      .update({ in_stock: !p.in_stock })
      .eq('id', p.id)
      .select('id');
    setBusyId(null);
    if (error || !data?.length) return setError(error?.message || 'Update nahi hua.');
    setProducts((list) => list.map((x) => (x.id === p.id ? { ...x, in_stock: !p.in_stock } : x)));
  };

  const remove = async (p) => {
    if (!window.confirm(`"${p.name}" ko hamesha ke liye delete karein?`)) return;
    setBusyId(p.id);
    const { data, error } = await supabase.from('products').delete().eq('id', p.id).select('id');
    setBusyId(null);
    if (error || !data?.length) return setError(error?.message || 'Delete nahi hua.');
    setProducts((list) => list.filter((x) => x.id !== p.id));
  };

  return (
    <div>
      <div className="mb-4 flex flex-col gap-3 sm:flex-row">
        <input
          type="search"
          className="input"
          placeholder="Product khojein..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <button onClick={() => setEditing('new')} className="btn-primary whitespace-nowrap">
          + Naya product
        </button>
      </div>

      {error && <p className="mb-3 rounded-xl bg-red-50 px-4 py-2 text-sm text-red-700">{error}</p>}
      {loading && <p className="py-10 text-center text-gray-500">Load ho raha hai...</p>}

      {!loading && filtered.length === 0 && (
        <div className="rounded-2xl bg-brand-50 p-8 text-center text-brand-800">
          Koi product nahi mila. Sample products ke liye supabase/seed.sql chalayein, ya “Naya product” dabayein.
        </div>
      )}

      <ul className="space-y-3">
        {filtered.map((p) => (
          <li key={p.id} className="card flex items-center gap-3 p-3">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={p.image_url || '/products/placeholder.svg'}
              alt=""
              onError={(e) => {
                e.currentTarget.onerror = null;
                e.currentTarget.src = '/products/placeholder.svg';
              }}
              className="h-16 w-16 shrink-0 rounded-xl bg-brand-50 object-cover"
            />
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold">{p.name}</p>
              <p className="text-xs text-gray-500">
                {p.category} • {p.unit} • <span className="font-bold text-brand-800">{formatPrice(p.price)}</span>
                {p.mrp ? <span className="text-gray-400"> (MRP {formatPrice(p.mrp)})</span> : null}
              </p>
              <button
                onClick={() => toggleStock(p)}
                disabled={busyId === p.id}
                className={`mt-1 rounded-full px-2.5 py-0.5 text-[11px] font-bold ${
                  p.in_stock ? 'bg-brand-100 text-brand-800' : 'bg-gray-200 text-gray-600'
                }`}
              >
                {p.in_stock ? 'Stock mein' : 'Stock khatam'} (badlein)
              </button>
            </div>
            <div className="flex flex-col gap-2 sm:flex-row">
              <button onClick={() => setEditing(p)} className="btn-outline !px-3 !py-1.5">Edit</button>
              <button onClick={() => remove(p)} disabled={busyId === p.id} className="btn-danger !px-3 !py-1.5">Delete</button>
            </div>
          </li>
        ))}
      </ul>

      {editing && (
        <ProductForm
          product={editing === 'new' ? null : editing}
          onClose={() => setEditing(null)}
          onSaved={() => {
            setEditing(null);
            load();
          }}
        />
      )}
    </div>
  );
}
