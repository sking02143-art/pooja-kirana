'use client';

export default function QuantityControl({ qty, onChange, size = 'md' }) {
  const btn =
    size === 'sm'
      ? 'h-8 w-8 text-base'
      : 'h-9 w-9 text-lg';
  return (
    <div className="inline-flex items-center overflow-hidden rounded-xl bg-brand-600 text-white shadow-sm">
      <button
        type="button"
        aria-label="Kam karein"
        onClick={() => onChange(qty - 1)}
        className={`${btn} font-bold transition hover:bg-brand-700 active:scale-90`}
      >
        −
      </button>
      <span className="min-w-[2rem] text-center text-sm font-bold" aria-live="polite">
        {qty}
      </span>
      <button
        type="button"
        aria-label="Badhayein"
        onClick={() => onChange(qty + 1)}
        disabled={qty >= 99}
        className={`${btn} font-bold transition hover:bg-brand-700 active:scale-90 disabled:opacity-50`}
      >
        +
      </button>
    </div>
  );
}
