import { CATEGORIES, STORE } from '@/lib/config';
import { whatsappLink } from '@/lib/utils';
import Logo from './Logo';

export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-brand-700 via-brand-600 to-brand-500 text-white">
      <div className="pointer-events-none absolute -right-16 -top-16 h-64 w-64 rounded-full bg-white/10 blur-2xl" />
      <div className="pointer-events-none absolute -bottom-20 left-10 h-56 w-56 rounded-full bg-brand-300/20 blur-2xl" />

      <div className="relative mx-auto max-w-6xl px-4 py-12 sm:py-16">
        <div className="max-w-xl animate-fadeUp">
          <div className="mb-4 flex items-center gap-3">
            <Logo className="h-12 w-12" />
            <span className="rounded-full bg-white/15 px-3 py-1 text-xs font-semibold backdrop-blur">
              Online Grocery Store
            </span>
          </div>
          <h1 className="text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl">
            {STORE.name}
          </h1>
          <p className="mt-3 text-lg text-brand-50">{STORE.tagline}</p>
          <p className="mt-2 text-sm text-brand-100">
            Atta, dal, tel, masale aur ghar ka sara saaman. Cart banayein aur order seedha WhatsApp par bhejein.
          </p>

          <div className="mt-6 flex flex-wrap gap-3">
            <a
              href="#shop"
              className="inline-flex items-center justify-center rounded-xl bg-white px-5 py-3 text-sm font-bold text-brand-700 shadow-soft transition hover:bg-brand-50 active:scale-95"
            >
              Shopping shuru karein
            </a>
            <a
              href={whatsappLink(`Namaste ${STORE.name}, mujhe order karna hai.`)}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center rounded-xl border border-white/40 px-5 py-3 text-sm font-bold text-white transition hover:bg-white/10 active:scale-95"
            >
              WhatsApp par baat karein
            </a>
          </div>
        </div>

        <ul className="relative mt-8 flex flex-wrap gap-2 text-sm">
          {CATEGORIES.map((c, i) => (
            <li
              key={c.name}
              style={{ animationDelay: `${i * 60}ms` }}
              className="animate-fadeUp rounded-full bg-white/15 px-3 py-1.5 backdrop-blur"
            >
              <span aria-hidden="true">{c.emoji}</span> {c.name}
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
