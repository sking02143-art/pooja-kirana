'use client';

import { useCart } from '@/lib/cart';
import { discountPercent, formatPrice } from '@/lib/utils';
import QuantityControl from './QuantityControl';

export default function ProductCard({ product, index = 0 }) {
  const { items, add, setQty } = useCart();
  const inCart = items.find((i) => i.id === product.id);
  const off = discountPercent(product.price, product.mrp);
  const outOfStock = product.in_stock === false;

  return (
    <article
      style={{ animationDelay: `${Math.min(index, 12) * 40}ms` }}
      className="group flex animate-fadeUp flex-col overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-card transition hover:-translate-y-1 hover:shadow-soft"
    >
      <div className="relative aspect-square overflow-hidden bg-brand-50">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={product.image_url || '/products/placeholder.svg'}
          alt={product.name}
          loading="lazy"
          onError={(e) => {
            e.currentTarget.onerror = null;
            e.currentTarget.src = '/products/placeholder.svg';
          }}
          className={`h-full w-full object-cover transition duration-500 group-hover:scale-105 ${
            outOfStock ? 'opacity-50 grayscale' : ''
          }`}
        />
        {off > 0 && !outOfStock && (
          <span className="absolute left-2 top-2 rounded-full bg-red-500 px-2 py-0.5 text-[11px] font-bold text-white">
            {off}% OFF
          </span>
        )}
        {outOfStock && (
          <span className="absolute inset-x-0 bottom-0 bg-gray-800/80 py-1 text-center text-xs font-semibold text-white">
            Stock khatam
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col p-3">
        <span className="text-[11px] font-semibold uppercase tracking-wide text-brand-600">
          {product.category}
        </span>
        <h3 className="mt-0.5 line-clamp-2 text-sm font-semibold leading-snug text-gray-900">
          {product.name}
        </h3>
        <p className="mt-0.5 text-xs text-gray-500">{product.unit}</p>

        <div className="mt-2 flex items-baseline gap-2">
          <span className="text-base font-extrabold text-brand-800">{formatPrice(product.price)}</span>
          {product.mrp > product.price && (
            <span className="text-xs text-gray-400 line-through">{formatPrice(product.mrp)}</span>
          )}
        </div>

        <div className="mt-3 flex h-9 items-center">
          {outOfStock ? (
            <button type="button" disabled className="btn-outline w-full !py-2">
              Uplabdh nahi
            </button>
          ) : inCart ? (
            <QuantityControl qty={inCart.qty} onChange={(q) => setQty(product.id, q)} />
          ) : (
            <button type="button" onClick={() => add(product)} className="btn-primary w-full !py-2">
              Cart mein daalein
            </button>
          )}
        </div>
      </div>
    </article>
  );
}
