# 🛒 Pooja Kirana – Online Grocery Store

Next.js 14 + React + Tailwind CSS + Supabase + PWA se bani poori e-commerce website.
Hara-safed premium design, mobile-first, WhatsApp ordering, admin dashboard aur offline support ke saath.

> **Dhyan dein:** Ye project abhi **deploy nahi hua hai**. Neeche diye steps se aap ise khud Vercel ya Netlify par deploy karenge.

---

## ✨ Features

- Homepage (Pooja Kirana branding, hero, category icons)
- 8 categories: Atta, Dal, Oil, Snacks, Dairy, Spices, Cleaning, Beverages
- Product search aur category filter
- Cart: add, quantity badhao/ghatao, hatao (cart phone mein save rehta hai)
- Checkout: naam, mobile, pata, note, payment (COD / UPI)
- **WhatsApp ordering**: order ka taiyaar message seedha dukaan ke WhatsApp par
- **UPI**: UPI ID + "UPI app kholein" link (placeholder – payment gateway nahi hai, neeche padhein)
- Order Supabase database mein save hota hai
- **Admin dashboard** (`/admin`): products add/edit/delete, stock on/off, orders dekhna aur status badalna
- **PWA**: phone mein install, offline support, offline page
- 32 sample products (daam ke saath) aur unki images (`public/products/`)

---

## 📁 Project Structure

```
pooja-kirana/
├── app/
│   ├── layout.js            → poori site ka dhancha (header, footer, PWA)
│   ├── globals.css          → Tailwind + common styles
│   ├── page.js              → Homepage
│   ├── cart/page.js         → Cart page
│   ├── checkout/page.js     → Checkout + WhatsApp + UPI
│   ├── offline/page.js      → Internet na hone par dikhne wala page
│   └── admin/               → Admin login + dashboard
├── components/              → Header, Footer, Hero, Shop, ProductCard, CartBar ...
│   └── admin/               → AdminProducts, AdminOrders, ProductForm
├── lib/                     → supabase.js, cart.js, products.js, utils.js, config.js
├── public/
│   ├── manifest.json        → PWA settings
│   ├── sw.js                → Service worker (offline)
│   ├── icons/               → App icons
│   └── products/            → Product images
├── supabase/
│   ├── schema.sql           → Database tables + security
│   └── seed.sql             → 32 sample products
├── .env.example             → Settings ka namuna
├── netlify.toml             → Netlify settings
└── package.json
```

---

## 🚀 Setup (Step by Step)

### Step 1: Zaroori software
- **Node.js 18.17 ya naya (20 behtar)** – https://nodejs.org se install karein
- Ek code editor (VS Code)

### Step 2: Packages install karein
Project folder mein terminal kholkar:
```bash
npm install
```

### Step 3: Supabase project banayein
1. https://supabase.com par free account banayein → **New project**
2. **SQL Editor** kholein:
   - `supabase/schema.sql` ka poora text paste karke **RUN** karein
   - phir `supabase/seed.sql` paste karke **RUN** karein (sample products aa jayenge)
3. **Project Settings → API** se ye do cheezein copy karein:
   - Project URL
   - `anon` `public` key

### Step 4: .env.local banayein
`.env.example` ko copy karke `.env.local` naam dein aur values bharein:
```
NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
NEXT_PUBLIC_WHATSAPP_NUMBER=919876543210
NEXT_PUBLIC_UPI_ID=aapka@upi
NEXT_PUBLIC_STORE_NAME=Pooja Kirana
```
- WhatsApp number **country code ke saath**, bina `+`, space ya `-` ke (India: `91` + 10 digit).
- `.env.local` ko kabhi GitHub par upload na karein (`.gitignore` ise already rok deta hai).
- Sirf **anon key** use karein. `service_role` key kabhi is project mein na daalein.

### Step 5: Admin user banayein
1. Supabase → **Authentication → Users → Add user** → apna email aur password daalein (**Auto Confirm User** chalu rakhein).
2. **SQL Editor** mein ye chalayein (apna wahi email likhein):
   ```sql
   insert into public.admins (email) values ('your-email@example.com');
   ```
3. (Suggested) **Authentication → Sign In / Providers → Email** mein naye logon ka **sign up band** kar dein.

### Step 6: Chalayein
```bash
npm run dev
```
Browser mein http://localhost:3000 kholein. Admin: http://localhost:3000/admin

---

## 📲 PWA (App install + Offline) test karna

Service worker sirf **production build** mein chalta hai:
```bash
npm run build
npm start
```
- http://localhost:3000 kholein, ek baar poori site dekh lein, phir **dobara reload** karein (taaki files save ho jayein).
- Chrome mein address bar ke paas **Install** ka icon aayega. iPhone Safari mein: **Share → Add to Home Screen**.
- Internet band karke site kholein: pehle dekhe hue pages aur saved products list dikhegi.
- Offline mein order **nahi** bheja ja sakta (internet chahiye).

---

## 🌐 Deploy karna

### Vercel
1. Project ko GitHub par push karein.
2. https://vercel.com → **Add New → Project** → apni repo chunein.
3. **Environment Variables** mein `.env.local` ki saari 5 values daalein.
4. **Deploy** dabayein.

### Netlify
1. Project ko GitHub par push karein.
2. https://netlify.com → **Add new site → Import from Git** → apni repo chunein.
3. Build command `npm run build` (`netlify.toml` mein pehle se hai).
4. **Site settings → Environment variables** mein saari 5 values daalein.
5. **Deploy** dabayein.

Deploy ke baad (dono par) Supabase → **Authentication → URL Configuration** mein apni site ka URL daal dein.

> Environment variables badalne ke baad site ko **dobara deploy** karna padta hai.

---

## 🔒 Security ki baatein

- Database par **Row Level Security** chalu hai:
  - Customers sirf products **dekh** sakte hain aur naya order **bhej** sakte hain.
  - Products badalna aur orders dekhna **sirf admins table ke emails** kar sakte hain.
- Admin ka login Supabase Auth se hota hai; password kisi file mein nahi hota.
- `anon` key public hoti hai (browser mein dikhti hai) – ye normal hai, suraksha RLS se aati hai.

---

## ⚠️ Zaroori jaankari (Ehtiyaat)

- **UPI sirf placeholder hai.** Isme payment gateway (Razorpay etc.) nahi juda. Customer apne UPI app se seedha aapke UPI ID par paise bhejta hai; payment apne aap verify nahi hota. Dukaan ko payment screenshot/received amount khud check karna hoga. Automatic verification chahiye to baad mein Razorpay/Cashfree jodna padega.
- **Product images** abhi generated SVG pictures hain (`public/products/`). Asli photos ke liye admin mein product edit karke image ka link badal dein, ya `public/products/` mein apni photo daalein.
- Delivery charge ka koi hisaab nahi joda gaya; dukaan WhatsApp par confirm karti hai.
- Agar Supabase keys nahi daale to site **demo mode** mein sample products dikhati hai, par order sirf WhatsApp se jayega aur admin panel kaam nahi karega.

---

## 🛠 Common problems

| Problem | Solution |
|---|---|
| Products nahi dikh rahe | `seed.sql` RUN kiya? `.env.local` ki keys sahi hain? Server dobara chalayein |
| Admin login ke baad "Access nahi hai" | Step 5 ka `insert into public.admins` apne email ke saath chalayein |
| WhatsApp par galat number khulta hai | `NEXT_PUBLIC_WHATSAPP_NUMBER` mein `91` ke saath poora number likhein |
| Install button nahi dikh raha | Site HTTPS par ho (deploy) ya `localhost` par `npm start` se chalayein |
| Naya version phone par nahi dikh raha | `public/sw.js` mein `VERSION` badal kar dobara deploy karein |

---

Banaya gaya ❤️ Pooja Kirana ke liye.
