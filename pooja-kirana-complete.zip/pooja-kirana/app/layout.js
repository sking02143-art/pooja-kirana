import './globals.css';
import { CartProvider } from '@/lib/cart';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import CartBar from '@/components/CartBar';
import PwaClient from '@/components/PwaClient';

export const metadata = {
  title: {
    default: 'Pooja Kirana - Online Grocery Store',
    template: '%s | Pooja Kirana',
  },
  description:
    'Pooja Kirana: atta, dal, tel, snacks, dairy, masale, cleaning aur beverages. Online order karein aur WhatsApp par bhejein.',
  applicationName: 'Pooja Kirana',
  manifest: '/manifest.json',
  appleWebApp: { capable: true, title: 'Pooja Kirana', statusBarStyle: 'default' },
  icons: {
    icon: '/favicon.ico',
    apple: '/icons/apple-touch-icon.png',
  },
};

export const viewport = {
  themeColor: '#16a34a',
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({ children }) {
  return (
    <html lang="hi">
      <body className="antialiased">
        <CartProvider>
          <PwaClient />
          <Header />
          <main className="min-h-[70vh] pb-24">{children}</main>
          <Footer />
          <CartBar />
        </CartProvider>
      </body>
    </html>
  );
}
