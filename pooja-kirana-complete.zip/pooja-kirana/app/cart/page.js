'use client';

import Link from 'next/link';
import { useCart } from '@/lib/cart';
import { formatPrice } from '@/lib/utils';
import QuantityControl from '@/components/QuantityControl';

export default function CartPage() {
  const { items, total, count, ready, setQty, remove, clear } = useCart();

  if (!ready) {
    return <div className="mx-auto max-w-3xl px-4 py-10 text-center text-gray-500">Cart load ho raha hai...</div>;
  }

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-16 text-center">
        <p className="text-5xl">🛒</p>
        <h1 className="mt-4 text-2xl font-extrabold text-brand-800">Aapka cart khali hai</h1>
        <p className="mt-1 text-gray-500">Kuch accha saaman cart mein daalein.</p>
        <Link href="/" className="btn-primary mt-6">
          Shopping shuru karein
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-6">
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-2xl font-extrabold text-brand-800">Aapka Cart ({count})</h1>
        <button
          type="button"
          onClick={() => {
            if (window.confirm('Pura cart khali karein?')) clear();
          }}
          className="text-sm font-semibold text-red-600 hover:underline"
        >
          Cart khali karein
        </button>
      </div>

      <ul className="space-y-3">
        {items.map((it) => (
          <li key={it.id} className="card flex animate-fadeUp items-center gap-3 p-3">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={it.image_url || '/products/placeholder.svg'}
              alt={it.name}
              onError={(e) => {
                e.currentTarget.onerror = null;
                e.currentTarget.src = '/products/placeholder.svg';
              }}
              className="h-20 w-20 shrink-0 rounded-xl bg-brand-50 object-cover"
            />
            <div className="min-w-0 flex-1">
              <p className="line-clamp-2 text-sm font-semibold text-gray-900">{it.name}</p>
              <p className="text-xs text-gray-500">
                {it.unit} • {formatPrice(it.price)}
              </p>
              <div className="mt-2 flex items-center justify-between">
                <QuantityControl qty={it.qty} onChange={(q) => setQty(it.id, q)} size="sm" />
                <span className="font-extrabold text-brand-800">{formatPrice(it.price * it.qty)}</span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => remove(it.id)}
              aria-label={`${it.name} hatayein`}
              className="self-start rounded-full p-1.5 text-gray-400 transition hover:bg-red-50 hover:text-red-500"
            >
              <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                <path d="M18 6 6 18M6 6l12 12" />
              </svg>
            </button>
          </li>
        ))}
      </ul>

      <div className="card mt-5 p-4">
        <div className="flex items-center justify-between text-lg">
          <span className="font-semibold text-gray-700">Total</span>
          <span className="text-2xl font-extrabold text-brand-800">{formatPrice(total)}</span>
        </div>
        <p className="mt-1 text-xs text-gray-500">Delivery ka charge (agar ho) dukaan confirm karte waqt bataegi.</p>
        <div className="mt-4 flex flex-col gap-2 sm:flex-row">
          <Link href="/" className="btn-outline sm:flex-1">
            Aur saaman jodein
          </Link>
          <Link href="/checkout" className="btn-primary sm:flex-1">
            Checkout karein
          </Link>
        </div>
      </div>
    </div>
  );
}
