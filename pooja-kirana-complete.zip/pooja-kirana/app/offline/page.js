export const metadata = { title: 'Offline' };

export default function OfflinePage() {
  return (
    <div className="mx-auto max-w-md px-4 py-20 text-center">
      <p className="text-5xl">📡</p>
      <h1 className="mt-4 text-2xl font-extrabold text-brand-800">Aap offline hain</h1>
      <p className="mt-2 text-gray-600">
        Internet nahi mil raha. Connection wapas aane par dobara koshish karein.
      </p>
      <a href="/" className="btn-primary mt-6">
        Dobara koshish karein
      </a>
    </div>
  );
}
