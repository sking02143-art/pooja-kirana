'use client';

import Link from 'next/link';
import { useState } from 'react';
import { useCart } from '@/lib/cart';
import { STORE } from '@/lib/config';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import {
  buildWhatsAppMessage,
  cleanPhone,
  formatPrice,
  isValidPhone,
  makeOrderNumber,
  upiLink,
  whatsappLink,
} from '@/lib/utils';

export default function CheckoutPage() {
  const { items, total, ready, clear } = useCart();
  const [form, setForm] = useState({ name: '', phone: '', address: '', notes: '' });
  const [payment, setPayment] = useState('COD');
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [placed, setPlaced] = useState(null); // { order, saved }
  const [copied, setCopied] = useState(false);

  const update = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const validate = () => {
    const e = {};
    if (form.name.trim().length < 2) e.name = 'Apna naam likhein';
    if (!isValidPhone(form.phone)) e.phone = '10 digit ka sahi mobile number likhein';
    if (form.address.trim().length < 10) e.address = 'Poora pata likhein (ghar/gali/area/pincode)';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = async (ev) => {
    ev.preventDefault();
    if (submitting || items.length === 0 || !validate()) return;
    setSubmitting(true);

    const order = {
      order_number: makeOrderNumber(),
      customer_name: form.name.trim(),
      phone: cleanPhone(form.phone),
      address: form.address.trim(),
      notes: form.notes.trim() || null,
      items: items.map((i) => ({ id: i.id, name: i.name, unit: i.unit, price: i.price, qty: i.qty })),
      total: Number(total.toFixed(2)),
      payment_method: payment,
      status: 'new',
    };

    let saved = false;
    if (isSupabaseConfigured) {
      const { error } = await supabase.from('orders').insert(order);
      saved = !error;
    }

    setPlaced({ order, saved });
    clear();
    setSubmitting(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (!ready) {
    return <div className="mx-auto max-w-2xl px-4 py-10 text-center text-gray-500">Load ho raha hai...</div>;
  }

  // ---------- Order ho gaya: WhatsApp / UPI step ----------
  if (placed) {
    const { order, saved } = placed;
    const message = buildWhatsAppMessage(order);
    return (
      <div className="mx-auto max-w-2xl animate-fadeUp px-4 py-8">
        <div className="card p-6 text-center">
          <p className="text-5xl">✅</p>
          <h1 className="mt-3 text-2xl font-extrabold text-brand-800">Order taiyaar hai!</h1>
          <p className="mt-1 text-gray-600">
            Order No: <span className="font-bold">{order.order_number}</span> • {formatPrice(order.total)}
          </p>

          {saved ? (
            <p className="mt-3 rounded-xl bg-brand-50 px-4 py-2 text-sm text-brand-800">
              Aapka order dukaan ke system mein save ho gaya hai.
            </p>
          ) : (
            <p className="mt-3 rounded-xl bg-amber-50 px-4 py-2 text-sm text-amber-800">
              Order online save nahi ho paaya. Kripya neeche wale button se WhatsApp par zaroor bhejein.
            </p>
          )}

          <a
            href={whatsappLink(message)}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary mt-5 w-full !py-3.5 !text-base"
          >
            WhatsApp par order bhejein
          </a>
          <p className="mt-2 text-xs text-gray-500">
            WhatsApp khulega aur order ka message pehle se likha hoga. Bas “Send” dabayein.
          </p>
        </div>

        {order.payment_method === 'UPI' && (
          <div className="card mt-4 p-5">
            <h2 className="font-bold text-brand-800">UPI se payment</h2>
            {STORE.upiId ? (
              <>
                <p className="mt-1 text-sm text-gray-600">
                  UPI ID: <span className="font-semibold">{STORE.upiId}</span> • Rakam:{' '}
                  <span className="font-semibold">{formatPrice(order.total)}</span>
                </p>
                <div className="mt-3 flex flex-col gap-2 sm:flex-row">
                  <a href={upiLink(order.total, order.order_number)} className="btn-outline sm:flex-1">
                    UPI app kholein
                  </a>
                  <button
                    type="button"
                    className="btn-outline sm:flex-1"
                    onClick={async () => {
                      try {
                        await navigator.clipboard.writeText(STORE.upiId);
                        setCopied(true);
                        setTimeout(() => setCopied(false), 2000);
                      } catch {}
                    }}
                  >
                    {copied ? 'Copy ho gaya ✓' : 'UPI ID copy karein'}
                  </button>
                </div>
                <p className="mt-3 text-xs text-gray-500">
                  Ye abhi payment placeholder hai: koi payment gateway juda nahi hai, isliye payment apne aap verify
                  nahi hota. Payment karke screenshot WhatsApp par bhej dein; dukaan use confirm karegi.
                </p>
              </>
            ) : (
              <p className="mt-1 text-sm text-amber-700">
                Dukaan ka UPI ID abhi set nahi hai. Kripya WhatsApp par dukaan se payment ka tareeka poochein.
              </p>
            )}
          </div>
        )}

        <div className="mt-5 text-center">
          <Link href="/" className="text-sm font-semibold text-brand-700 hover:underline">
            ← Wapas dukaan par jaayein
          </Link>
        </div>
      </div>
    );
  }

  // ---------- Cart khali ----------
  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 text-center">
        <p className="text-5xl">🛒</p>
        <h1 className="mt-4 text-2xl font-extrabold text-brand-800">Cart khali hai</h1>
        <Link href="/" className="btn-primary mt-6">
          Shopping shuru karein
        </Link>
      </div>
    );
  }

  // ---------- Customer details form ----------
  return (
    <div className="mx-auto max-w-2xl px-4 py-6">
      <h1 className="text-2xl font-extrabold text-brand-800">Checkout</h1>

      <div className="card mt-4 p-4">
        <h2 className="mb-2 text-sm font-bold uppercase tracking-wide text-gray-500">Order summary</h2>
        <ul className="divide-y divide-gray-100 text-sm">
          {items.map((it) => (
            <li key={it.id} className="flex justify-between gap-3 py-2">
              <span className="text-gray-700">
                {it.name} <span className="text-gray-400">({it.unit}) × {it.qty}</span>
              </span>
              <span className="font-semibold">{formatPrice(it.price * it.qty)}</span>
            </li>
          ))}
        </ul>
        <div className="mt-2 flex justify-between border-t border-gray-100 pt-3 text-lg">
          <span className="font-bold">Total</span>
          <span className="font-extrabold text-brand-800">{formatPrice(total)}</span>
        </div>
      </div>

      <form onSubmit={submit} noValidate className="card mt-4 space-y-4 p-4">
        <h2 className="text-sm font-bold uppercase tracking-wide text-gray-500">Aapki jaankari</h2>

        <div>
          <label htmlFor="name" className="label">Naam *</label>
          <input id="name" className="input" value={form.name} onChange={update('name')} autoComplete="name" placeholder="Jaise: Ramesh Kumar" />
          {errors.name && <p className="mt-1 text-xs text-red-600">{errors.name}</p>}
        </div>

        <div>
          <label htmlFor="phone" className="label">Mobile number *</label>
          <input id="phone" className="input" value={form.phone} onChange={update('phone')} inputMode="numeric" autoComplete="tel" maxLength={14} placeholder="10 digit number" />
          {errors.phone && <p className="mt-1 text-xs text-red-600">{errors.phone}</p>}
        </div>

        <div>
          <label htmlFor="address" className="label">Delivery pata *</label>
          <textarea id="address" rows={3} className="input" value={form.address} onChange={update('address')} autoComplete="street-address" placeholder="Ghar no., gali, area, shehar, pincode" />
          {errors.address && <p className="mt-1 text-xs text-red-600">{errors.address}</p>}
        </div>

        <div>
          <label htmlFor="notes" className="label">Koi note (zaroori nahi)</label>
          <input id="notes" className="input" value={form.notes} onChange={update('notes')} placeholder="Jaise: shaam 6 baje ke baad" />
        </div>

        <fieldset>
          <legend className="label">Payment ka tareeka</legend>
          <div className="grid grid-cols-2 gap-3">
            {[
              { id: 'COD', title: 'Cash on Delivery', sub: 'Saaman milne par' },
              { id: 'UPI', title: 'UPI', sub: 'GPay / PhonePe / Paytm' },
            ].map((opt) => (
              <label
                key={opt.id}
                className={`cursor-pointer rounded-xl border-2 p-3 text-sm transition ${
                  payment === opt.id ? 'border-brand-600 bg-brand-50' : 'border-gray-200 hover:border-brand-200'
                }`}
              >
                <input
                  type="radio"
                  name="payment"
                  value={opt.id}
                  checked={payment === opt.id}
                  onChange={() => setPayment(opt.id)}
                  className="sr-only"
                />
                <span className="block font-bold text-gray-900">{opt.title}</span>
                <span className="block text-xs text-gray-500">{opt.sub}</span>
              </label>
            ))}
          </div>
        </fieldset>

        <button type="submit" disabled={submitting} className="btn-primary w-full !py-3.5 !text-base">
          {submitting ? 'Order ban raha hai...' : 'Order karein'}
        </button>
        <p className="text-center text-xs text-gray-500">
          Order dabane ke baad aapko WhatsApp par bhejne ka button milega.
        </p>
      </form>
    </div>
  );
}
