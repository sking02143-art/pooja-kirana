'use client';

import { useEffect, useState } from 'react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import AdminProducts from '@/components/admin/AdminProducts';
import AdminOrders from '@/components/admin/AdminOrders';

function LoginForm() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    if (error) setError('Email ya password galat hai.');
    setLoading(false);
  };

  return (
    <div className="mx-auto max-w-sm px-4 py-12">
      <form onSubmit={submit} className="card space-y-4 p-6">
        <div className="text-center">
          <p className="text-4xl">🔐</p>
          <h1 className="mt-2 text-xl font-extrabold text-brand-800">Admin Login</h1>
        </div>
        <div>
          <label htmlFor="email" className="label">Email</label>
          <input id="email" type="email" required autoComplete="username" className="input" value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        <div>
          <label htmlFor="password" className="label">Password</label>
          <input id="password" type="password" required autoComplete="current-password" className="input" value={password} onChange={(e) => setPassword(e.target.value)} />
        </div>
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button type="submit" disabled={loading} className="btn-primary w-full">
          {loading ? 'Login ho raha hai...' : 'Login'}
        </button>
      </form>
    </div>
  );
}

export default function AdminPage() {
  const [session, setSession] = useState(null);
  const [sessionLoaded, setSessionLoaded] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [checking, setChecking] = useState(true);
  const [tab, setTab] = useState('products');

  useEffect(() => {
    if (!isSupabaseConfigured) return;
    let active = true;
    supabase.auth.getSession().then(({ data }) => {
      if (!active) return;
      setSession(data.session);
      setSessionLoaded(true);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_event, s) => setSession(s));
    return () => {
      active = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    if (!isSupabaseConfigured || !sessionLoaded) return;
    if (!session) {
      setIsAdmin(false);
      setChecking(false);
      return;
    }
    let active = true;
    setChecking(true);
    supabase.rpc('is_admin').then(({ data, error }) => {
      if (!active) return;
      setIsAdmin(!error && data === true);
      setChecking(false);
    });
    return () => {
      active = false;
    };
  }, [session, sessionLoaded]);

  if (!isSupabaseConfigured) {
    return (
      <div className="mx-auto max-w-lg px-4 py-16 text-center">
        <p className="text-4xl">⚙️</p>
        <h1 className="mt-3 text-xl font-extrabold text-brand-800">Supabase connect nahi hai</h1>
        <p className="mt-2 text-sm text-gray-600">
          Admin panel ke liye .env.local mein NEXT_PUBLIC_SUPABASE_URL aur NEXT_PUBLIC_SUPABASE_ANON_KEY daalein, phir server dobara chalayein. Poori guide README.md mein hai.
        </p>
      </div>
    );
  }

  if (!sessionLoaded || checking) {
    return <div className="px-4 py-16 text-center text-gray-500">Load ho raha hai...</div>;
  }

  if (!session) return <LoginForm />;

  const logout = () => supabase.auth.signOut();

  if (!isAdmin) {
    return (
      <div className="mx-auto max-w-lg px-4 py-16 text-center">
        <p className="text-4xl">⛔</p>
        <h1 className="mt-3 text-xl font-extrabold text-red-700">Access nahi hai</h1>
        <p className="mt-2 text-sm text-gray-600">
          {session.user.email} admin list mein nahi hai. schema.sql ke aakhir mein diya gaya admins insert command apne email ke saath chalayein.
        </p>
        <button onClick={logout} className="btn-outline mt-5">Logout</button>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-6">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-brand-800">Admin Dashboard</h1>
          <p className="text-xs text-gray-500">{session.user.email}</p>
        </div>
        <button onClick={logout} className="btn-outline !py-2">Logout</button>
      </div>

      <div className="mb-5 inline-flex rounded-xl bg-brand-50 p-1" role="tablist">
        {[
          { id: 'products', label: 'Products' },
          { id: 'orders', label: 'Orders' },
        ].map((t) => (
          <button
            key={t.id}
            role="tab"
            aria-selected={tab === t.id}
            onClick={() => setTab(t.id)}
            className={`rounded-lg px-5 py-2 text-sm font-semibold transition ${
              tab === t.id ? 'bg-brand-600 text-white shadow-sm' : 'text-brand-700 hover:bg-brand-100'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'products' ? <AdminProducts /> : <AdminOrders />}
    </div>
  );
}
