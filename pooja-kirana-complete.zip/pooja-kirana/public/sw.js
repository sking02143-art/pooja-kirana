/* Pooja Kirana - Service Worker (offline support)
   - Pages: pehle internet, na mile to saved copy, warna /offline page
   - Static files (JS, CSS, images, icons): pehle saved copy, phir internet
   - Supabase aur doosri sites ke requests ko hum nahi chhedte (app khud cache sambhalta hai)
   Naya version nikalne par VERSION badal dein taaki purana cache hat jaye. */

const VERSION = 'pk-v1';
const PAGE_CACHE = `${VERSION}-pages`;
const STATIC_CACHE = `${VERSION}-static`;

const PRECACHE = [
  '/',
  '/cart',
  '/checkout',
  '/offline',
  '/manifest.json',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
  '/products/placeholder.svg',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(PAGE_CACHE)
      .then((cache) => Promise.allSettled(PRECACHE.map((url) => cache.add(url))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

async function networkFirstPage(request) {
  try {
    const response = await fetch(request);
    if (response && response.ok) {
      const cache = await caches.open(PAGE_CACHE);
      cache.put(request, response.clone());
    }
    return response;
  } catch (err) {
    const cached = await caches.match(request);
    if (cached) return cached;
    const offline = await caches.match('/offline');
    if (offline) return offline;
    return new Response('Offline', { status: 503, headers: { 'Content-Type': 'text/plain' } });
  }
}

async function cacheFirst(request) {
  const cached = await caches.match(request);
  if (cached) return cached;
  const response = await fetch(request);
  if (response && response.ok) {
    const cache = await caches.open(STATIC_CACHE);
    cache.put(request, response.clone());
  }
  return response;
}

const STATIC_PATTERN = /\.(?:png|jpg|jpeg|webp|svg|ico|css|js|woff2?)$/i;

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return; // Supabase etc. ko mat chhedo
  if (url.pathname.startsWith('/admin')) return; // Admin hamesha live rahe
  if (url.pathname.startsWith('/api/')) return;

  if (request.mode === 'navigate') {
    event.respondWith(networkFirstPage(request));
    return;
  }

  if (url.pathname.startsWith('/_next/static/') || STATIC_PATTERN.test(url.pathname) || url.pathname === '/manifest.json') {
    event.respondWith(cacheFirst(request));
  }
});
