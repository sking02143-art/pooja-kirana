-- =====================================================
-- Pooja Kirana - Sample products (schema.sql ke BAAD RUN karein)
-- Ye tabhi chalega jab products table khali ho, isliye dobara run karne se duplicate nahi banenge.
-- =====================================================
insert into public.products (name, category, price, mrp, unit, image_url, description, in_stock)
select * from (values
  ('Chakki Fresh Whole Wheat Atta', 'Atta', 245, 270, '5 kg', '/products/chakki-atta.svg', 'Taaza pisa hua chakki atta, mulayam rotiyon ke liye.', true),
  ('Multigrain Atta', 'Atta', 310, 345, '5 kg', '/products/multigrain-atta.svg', 'Gehun, chana, jowar aur ragi ka poshtik mix.', true),
  ('Besan (Gram Flour)', 'Atta', 115, 130, '1 kg', '/products/besan.svg', 'Pakode, kadhi aur ladoo ke liye mahin besan.', true),
  ('Suji (Semolina)', 'Atta', 52, 60, '1 kg', '/products/suji.svg', 'Upma, halwa aur idli ke liye badiya suji.', true),
  ('Toor Dal (Arhar)', 'Dal', 165, 185, '1 kg', '/products/toor-dal.svg', 'Roz ki dal ke liye saaf-suthri toor dal.', true),
  ('Moong Dal (Dhuli)', 'Dal', 130, 145, '1 kg', '/products/moong-dal.svg', 'Halki aur jaldi pakne wali moong dal.', true),
  ('Chana Dal', 'Dal', 98, 110, '1 kg', '/products/chana-dal.svg', 'Dal fry aur tadke ke liye swadisht chana dal.', true),
  ('Masoor Dal (Dhuli)', 'Dal', 92, 105, '1 kg', '/products/masoor-dal.svg', 'Jaldi galne wali, protein se bharpur masoor dal.', true),
  ('Refined Sunflower Oil', 'Oil', 145, 160, '1 L', '/products/sunflower-oil.svg', 'Halka aur roz ke khane ke liye refined tel.', true),
  ('Kachi Ghani Mustard Oil', 'Oil', 175, 190, '1 L', '/products/mustard-oil.svg', 'Tez khushboo wala kachi ghani sarson ka tel.', true),
  ('Pure Desi Ghee', 'Oil', 340, 375, '500 ml', '/products/desi-ghee.svg', 'Khushboodar shuddh desi ghee.', true),
  ('Groundnut Oil', 'Oil', 210, 230, '1 L', '/products/groundnut-oil.svg', 'Talne aur tadke ke liye moongphali ka tel.', true),
  ('Aloo Bhujia', 'Snacks', 85, 95, '400 g', '/products/aloo-bhujia.svg', 'Chatpati aur kurkuri aloo bhujia.', true),
  ('Salted Namkeen Mixture', 'Snacks', 80, 90, '400 g', '/products/namkeen-mixture.svg', 'Chai ke saath khane layak namkeen mixture.', true),
  ('Marie Biscuits', 'Snacks', 30, 35, '250 g', '/products/marie-biscuits.svg', 'Chai mein dubone wale halke meethe biscuit.', true),
  ('Potato Chips Classic Salted', 'Snacks', 20, NULL, '52 g', '/products/potato-chips.svg', 'Kurkure namkeen aloo chips.', true),
  ('Full Cream Milk', 'Dairy', 66, 68, '1 L', '/products/full-cream-milk.svg', 'Full cream doodh, chai aur dahi ke liye.', true),
  ('Fresh Paneer', 'Dairy', 90, 100, '200 g', '/products/fresh-paneer.svg', 'Narm aur taaza paneer.', true),
  ('Curd (Dahi)', 'Dairy', 40, 45, '400 g', '/products/curd-dahi.svg', 'Jamayi hui taaza, mulayam dahi.', true),
  ('Salted Butter', 'Dairy', 58, 62, '100 g', '/products/salted-butter.svg', 'Paratha aur toast ke liye namkeen makkhan.', true),
  ('Haldi Powder', 'Spices', 52, 60, '200 g', '/products/haldi-powder.svg', 'Gehre rang wali shuddh haldi.', true),
  ('Red Chilli Powder', 'Spices', 78, 90, '200 g', '/products/red-chilli-powder.svg', 'Teekha aur chatak lal mirch powder.', true),
  ('Coriander Powder (Dhaniya)', 'Spices', 60, 68, '200 g', '/products/coriander-powder.svg', 'Sugandhit pisa hua dhaniya.', true),
  ('Garam Masala', 'Spices', 82, 95, '100 g', '/products/garam-masala.svg', 'Sabji aur pulao ke liye khushboodar garam masala.', true),
  ('Detergent Powder', 'Cleaning', 110, 125, '1 kg', '/products/detergent-powder.svg', 'Kapdon ki safai ke liye detergent powder.', true),
  ('Dishwash Liquid', 'Cleaning', 95, 110, '500 ml', '/products/dishwash-liquid.svg', 'Chikni bartan ke liye lemon dishwash liquid.', true),
  ('Floor Cleaner', 'Cleaning', 175, 195, '1 L', '/products/floor-cleaner.svg', 'Farsh ko chamkane wala khushboodar cleaner.', true),
  ('Hand Wash Liquid', 'Cleaning', 89, 99, '250 ml', '/products/hand-wash.svg', 'Haathon ko komal rakhne wala hand wash.', true),
  ('Tea Leaves (Chai Patti)', 'Beverages', 245, 270, '500 g', '/products/tea-leaves.svg', 'Kadak aur khushboodar assam chai patti.', true),
  ('Instant Coffee', 'Beverages', 285, 310, '100 g', '/products/instant-coffee.svg', 'Jhatpat banne wali garam coffee.', true),
  ('Mango Drink', 'Beverages', 70, 80, '1 L', '/products/mango-drink.svg', 'Thanda aur meetha aam ka juice drink.', true),
  ('Cold Drink (Cola)', 'Beverages', 95, 100, '2 L', '/products/cold-drink.svg', 'Party ke liye thanda cola.', true)
) as v(name, category, price, mrp, unit, image_url, description, in_stock)
where not exists (select 1 from public.products);
