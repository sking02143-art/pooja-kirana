-- =====================================================
-- Pooja Kirana - Supabase Database Schema
-- Supabase Dashboard > SQL Editor mein paste karke RUN karein.
-- =====================================================

-- 1) Products table
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null check (category in
    ('Atta','Dal','Oil','Snacks','Dairy','Spices','Cleaning','Beverages')),
  price numeric(10,2) not null check (price >= 0),
  mrp numeric(10,2) check (mrp >= 0),
  unit text not null default '1 kg',
  image_url text,
  description text,
  in_stock boolean not null default true,
  created_at timestamptz not null default now()
);

-- 2) Orders table
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique,
  customer_name text not null,
  phone text not null,
  address text not null,
  notes text,
  items jsonb not null,
  total numeric(10,2) not null check (total >= 0),
  payment_method text not null default 'COD'
    check (payment_method in ('COD','UPI')),
  status text not null default 'new'
    check (status in ('new','confirmed','delivered','cancelled')),
  created_at timestamptz not null default now()
);

-- 3) Admins table (sirf in emails ko admin access milega)
create table if not exists public.admins (
  email text primary key
);

-- 4) Helper: kya current logged-in user admin hai?
create or replace function public.is_admin()
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select exists (
    select 1 from public.admins
    where lower(email) = lower(coalesce(auth.jwt() ->> 'email', ''))
  );
$$;

-- 5) Row Level Security (suraksha) ON karein
alter table public.products enable row level security;
alter table public.orders   enable row level security;
alter table public.admins   enable row level security;

-- Products: sab dekh sakte hain, sirf admin badal sakta hai
drop policy if exists "products_read_all"   on public.products;
drop policy if exists "products_admin_all"  on public.products;
create policy "products_read_all" on public.products
  for select using (true);
create policy "products_admin_all" on public.products
  for all using (public.is_admin()) with check (public.is_admin());

-- Orders: koi bhi customer order bhej sakta hai, sirf admin dekh/badal sakta hai
drop policy if exists "orders_insert_public" on public.orders;
drop policy if exists "orders_admin_all"     on public.orders;
create policy "orders_insert_public" on public.orders
  for insert with check (status = 'new');
create policy "orders_admin_all" on public.orders
  for all using (public.is_admin()) with check (public.is_admin());

-- Admins table: koi direct access nahi (sirf is_admin() function andar se padhta hai)

-- =====================================================
-- ADMIN BANANE KE LIYE (apna email likhein aur ek baar RUN karein):
-- insert into public.admins (email) values ('your-email@example.com');
-- Phir Supabase > Authentication > Users mein is email se user banayein.
-- =====================================================
